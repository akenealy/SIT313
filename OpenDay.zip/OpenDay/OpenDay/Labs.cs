using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace OpenDay
{
    [Activity(Label ="@string/Labs")]
    public class Labs : Activity
    {
        LabData[] labs;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Labs);

            labs = new LabData[] {new LabData("B1.01"), new LabData("B1.03"), new LabData("B1.06"), new LabData("B2.05"),
                new LabData("B3.01"), new LabData("B3.03"), new LabData("B3.06"), new LabData("B3.08"), new LabData("B3.12"),
                new LabData("B4.05"), new LabData("B4.07"), new LabData("4.10"), new LabData("B4.13"), new LabData("B4.16"),
                new LabData("B4.17"), new LabData("T1.01"), new LabData("T1.02"), new LabData("T1.03"), new LabData("T1.05"),
                new LabData("T10.6") };
            ListView lablist = (ListView)FindViewById<ListView>(Resource.Id.listview1);
            lablist.Adapter = new ArrayAdapter<LabData>(this, Resource.Layout.List, labs);

            lablist.ItemClick += (object sender, AdapterView.ItemClickEventArgs args) => OnLabClick(sender, args);
            Button Return = FindViewById<Button>(Resource.Id.buttonreturn);
            Return.Click += (sender, e) =>
            {
                var intent = new Intent(this, typeof(MainActivity));
                StartActivity(intent);
            };
        }

        protected void OnLabClick(object sender, EventArgs e)
        {
            AdapterView.ItemClickEventArgs args = (AdapterView.ItemClickEventArgs)e;
            var lab = labs[args.Position];
            var lablist = new Intent(this, typeof(LabDisplay));
            StartActivity(lablist);
        }
    }

    public class LabData
    {
        public LabData(string room)
        {
            LabRoom = room;
        }

        public string LabRoom { get; set; }
    }
}